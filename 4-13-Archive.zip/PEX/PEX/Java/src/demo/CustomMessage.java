package demo;

import com.intersystems.enslib.pex.Message;

public class CustomMessage extends com.intersystems.enslib.pex.Message {
    String name;
    String number;
    String address;
    String city;
}