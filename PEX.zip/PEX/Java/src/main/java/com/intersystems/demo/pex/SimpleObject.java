package com.intersystems.demo.pex;

public class SimpleObject {

	public String value = null;
	
	public SimpleObject(String initStringValue) {
		value = initStringValue;
	}

}
