package com.intersystems.demo.pex;


import com.intersystems.demo.pex.csvReq;
import java.io.File;  // Import the File class
import java.io.IOException;  // Import the IOException class to handle errors
import java.io.FileWriter;   // Import the FileWriter class
import java.io.IOException;  // Import the IOException class to handle errors

public class ZacksProcess extends com.intersystems.enslib.pex.BusinessProcess {
	

	

	
	
	
	public Object OnRequest(com.intersystems.enslib.pex.Message req) throws Exception  {
            // req.Name = "harry";
            FileWriter myWriter = new FileWriter("/datavol/PEX/messageContents.txt");
            myWriter.write("Files in Java might be tricky, but it is fun enough!");
            myWriter.close();
			csvReq request = (csvReq) req;
            SendRequestAsync("EnsLib.RecordMap.Operation.FileOperation", request, false);
            
 
               
              
            
          
		return null;
	}
	public static void main(String[] args) {
		System.out.println("Test");
	}
  

    
    

}
