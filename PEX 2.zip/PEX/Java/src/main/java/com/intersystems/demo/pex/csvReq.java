package com.intersystems.demo.pex;



public class csvReq extends com.intersystems.enslib.pex.Message {
    public String Name;

    public String Phone;

    public String Company;

    public String City;

}