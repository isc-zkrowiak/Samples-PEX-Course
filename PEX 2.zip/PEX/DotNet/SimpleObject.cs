﻿using System;

namespace InterSystems.Demo.PEX
{
    class SimpleObject
    {
        public String value = null;

        public SimpleObject(string initStringValue)
        {
            value = initStringValue;
        }

    }
}
